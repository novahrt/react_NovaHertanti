import React, { useState } from "react";
import CreateProduct from "./CreateProduct";
import { BrowserRouter, Route, Switch, Link as RouterLink } from "react-router-dom";
import "./styles.css";
import RegistrationForm from "./components/RegistrationForm";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = () => {
    setIsAuthenticated(true);
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <BrowserRouter>
      <div>
        <nav>
          <ul>
            <li>
              <RouterLink to="/register">Registrasi</RouterLink>
            </li>
            <li>
              <RouterLink to="/login">Login</RouterLink>
            </li>
            <li>
              <RouterLink to="/create-product">Create Product</RouterLink>
            </li>
          </ul>
        </nav>

        <Switch>
          <Route path="/register">
            {/* Halaman registrasi (Anda dapat menambahkan komponen RegistrationForm di sini) */}
            <RegistrationForm />
          </Route>
          <Route path="/login">
            {/* Halaman login */}
            {isAuthenticated ? (
              <div>
                <p>Selamat datang! Anda sudah login.</p>
                <button onClick={logout}>Logout</button>
              </div>
            ) : (
              <div>
                <p>Silakan login untuk mengakses Create Product.</p>
                <button onClick={login}>Login</button>
              </div>
            )}
          </Route>
          <Route path="/create-product">
            {/* Halaman CreateProduct */}
            {isAuthenticated ? (
              <CreateProduct />
            ) : (
              <div>
                <p>Silakan login untuk mengakses halaman Create Product.</p>
                <button onClick={login}>Login</button>
              </div>
            )}
          </Route>
          <Route path="/">
            {/* Halaman utama (LandingPage) */}
            <h2>Halaman Utama (LandingPage)</h2>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
