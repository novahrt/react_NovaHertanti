import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import CreateProduct from './CreateProduct';

test('memastikan bahwa form input Product Name dapat menerima input teks', () => {
  const { getByLabelText, getByText } = render(<CreateProduct />);
  
  // Mencari elemen input dengan label "Product Name"
  const productNameInput = getByLabelText('Product Name');

  // Mengisi input dengan teks
  fireEvent.change(productNameInput, { target: { value: 'Contoh Product' } });

  // Memeriksa apakah input telah terisi dengan benar
  expect(productNameInput.value).toBe('Contoh Product');
});

test('memastikan bahwa pilihan setiap form yang dipilih dapat disimpan dan ditampilkan dengan benar', () => {
  const { getByLabelText, getByText } = render(<CreateProduct />);
  
  // Mencari elemen input dengan label "Category"
  const categoryInput = getByLabelText('Category');

  // Mengisi input dengan pilihan kategori
  fireEvent.change(categoryInput, { target: { value: 'Electronics' } });

  // Memeriksa apakah input telah terisi dengan benar
  expect(categoryInput.value).toBe('Electronics');

  // Mencari elemen input dengan label "Stock"
  const stockInput = getByLabelText('Stock');

  // Mengisi input dengan jumlah stok
  fireEvent.change(stockInput, { target: { value: '10' } });

  // Memeriksa apakah input telah terisi dengan benar
  expect(stockInput.value).toBe('10');
});

test('memastikan bahwa Product Name tidak boleh kosong', () => {
  render(<CreateProduct />);
  
  // Temukan elemen input Product Name
  const productNameInput = screen.getByLabelText('Product Name');
  
  // Cobalah mengirimkan formulir tanpa mengisi Product Name
  fireEvent.click(screen.getByText('Submit'));
  
  // Temukan pesan kesalahan yang sesuai dan pastikan ditampilkan
  expect(screen.getByText('Product Name is required')).toBeInTheDocument();
});

test('memastikan bahwa Product Name tidak mengandung karakter @/#{}', () => {
  render(<CreateProduct />);
  
  // Temukan elemen input Product Name
  const productNameInput = screen.getByLabelText('Product Name');
  
  // Isi input dengan karakter yang tidak diizinkan
  fireEvent.change(productNameInput, { target: { value: '@Invalid#Name{}' } });
  
  // Cobalah mengirimkan formulir
  fireEvent.click(screen.getByText('Submit'));
  
  // Temukan pesan kesalahan yang sesuai dan pastikan ditampilkan
  expect(screen.getByText('Product Name contains invalid characters')).toBeInTheDocument();
});

test('memastikan bahwa Product Name tidak melebihi 25 karakter', () => {
  render(<CreateProduct />);
  
  // Temukan elemen input Product Name
  const productNameInput = screen.getByLabelText('Product Name');
  
  // Isi input dengan lebih dari 25 karakter
  fireEvent.change(productNameInput, { target: { value: 'Product Name with more than 25 characters' } });
  
  // Cobalah mengirimkan formulir
  fireEvent.click(screen.getByText('Submit'));
  
  // Temukan pesan kesalahan yang sesuai dan pastikan ditampilkan
  expect(screen.getByText('Product Name must not exceed 25 characters')).toBeInTheDocument();
});

test('memastikan bahwa semua form field tidak boleh kosong', () => {
  render(<CreateProduct />);
  
  // Cobalah mengirimkan formulir tanpa mengisi semua field
  fireEvent.click(screen.getByText('Submit'));
  
  // Temukan pesan kesalahan yang sesuai dan pastikan ditampilkan untuk setiap field yang kosong
  expect(screen.getByText('Product Name is required')).toBeInTheDocument();
  expect(screen.getByText('Category is required')).toBeInTheDocument();
  expect(screen.getByText('Stock is required')).toBeInTheDocument();
  expect(screen.getByText('Price is required')).toBeInTheDocument();
});

test('memastikan bahwa form menampilkan pesan error saat terjadi kesalahan saat menyimpan data ke state', () => {
    const { getByLabelText, getByText } = render(<CreateProduct />);
    
    // Mencari elemen input dengan label "Product Name"
    const productNameInput = getByLabelText('Product Name');
  
    // Mengisi input dengan teks yang valid
    fireEvent.change(productNameInput, { target: { value: 'Contoh Product' } });
  
    // Mengklik tombol Submit untuk menyimpan data ke state (misalnya, pada saat pengiriman data ke server)
    fireEvent.click(screen.getByText('Submit'));
  
    // Pastikan pesan error tidak ditampilkan
    expect(screen.queryByText('Error: Failed to save data')).toBeNull();
  
    // Mengklik tombol Submit dengan maksud memicu kesalahan
    fireEvent.click(screen.getByText('Error'));
  
    // Pastikan pesan error ditampilkan
    expect(screen.getByText('Error: Failed to save data')).toBeInTheDocument();
  });
