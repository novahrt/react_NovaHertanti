import React, { Component } from 'react';
import { Link } from "react-router-dom";
import "./styles.css";
import axios from 'axios';

class CreateProduct extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productName: '',
            productCategory: 'choose',
            productPrice: '',
            additionalDescription: '',
            productFreshness: {
                brandNew: false,
                secondHand: false,
                refurbished: false,
            },
            selectedFile: null, // Menambahkan state untuk menyimpan file yang dipilih
            isDataSaved: false,
            tableData: [],
            errors: {}, // Menambahkan state untuk menyimpan pesan kesalahan
        };
    }

    validateForm = () => {
        const { productName, productCategory, productPrice, selectedFile } = this.state;
        const { productFreshness } = this.state;
        const errors = {};

        const productNamePattern = /^[a-zA-Z0-9\s]{6,50}$/;
        if (!productNamePattern.test(productName)) {
            errors.productName = "Product Name must be between 6 and 50 alphanumeric characters.";
        }

        if (productCategory === 'choose') {
            errors.productCategory = "Please select a valid Product Category.";
        }

        const productPricePattern = /^\d+$/;
        if (!productPricePattern.test(productPrice)) {
            errors.productPrice = "Product Price must be a positive number.";
        }

        const selectedFreshnessCount = Object.values(productFreshness).filter(value => value).length;
        if (selectedFreshnessCount !== 1) {
            errors.productFreshness = "Please select one Product Freshness option.";
        }

        if (!selectedFile) {
            errors.selectedFile = "Please choose an image file.";
        }

        this.setState({ errors });

        return Object.keys(errors).length === 0;
    };

    handleInputChange = (event) => {
        const { name, value, type, checked } = event.target;
        if (type === 'checkbox') {
            this.setState({
                productFreshness: {
                    brandNew: false,
                    secondHand: false,
                    refurbished: false,
                    [name]: checked,
                },
            });
        } else {
            this.setState({ [name]: value });
        }
    };

    handleChooseFile = () => {
        const fileInput = document.getElementById('fileInput');
        fileInput.click();
    };

    handleFileChange = (event) => {
        const selectedFile = event.target.files[0];
        this.setState({ selectedFile });
    };

    addToTable = () => {
        const {
            productName,
            productCategory,
            productPrice,
            additionalDescription,
            productFreshness,
            selectedFile,
        } = this.state;

        if (this.validateForm()) {
            const productData = {
                productName,
                productCategory,
                productPrice,
                additionalDescription,
                productFreshness,
                selectedFile, // Menyimpan file yang dipilih dalam objek data produk
            };

            // Menggunakan Axios untuk mengirim data produk ke server
            axios.post('29165fa88b7b69c20cbf094a', productData)
                .then(response => {
                    console.log('Data berhasil dikirim:', response.data);
                    // Tambahkan logika atau pembaruan state sesuai kebutuhan Anda
                })
                .catch(error => {
                    console.error('Gagal mengirim data:', error);
                    // Handle kesalahan jika terjadi
                });

            this.setState((prevState) => ({
                tableData: [...prevState.tableData, productData],
                isDataSaved: true,
            }));
        }
    };

    renderTable = () => {
        const { tableData } = this.state;

        return (
            <table>
                {/* Table code ... */}
            </table>
        );
    };

    render() {
        const { isDataSaved, errors } = this.state;

        return (
            <div>
                <div className="navbar">
                    {/* Navbar code ... */}
                </div>
                <div>
                    <h1>Create Product</h1>
                    <Link to="/register">Go to Registration</Link>
                    {/* Isi form Create Product */}
                </div>
                <br />
                <br />
                <main>
                    <div className="content" id="content-section">
                        {/* Content code ... */}
                    </div>
                </main>
                <div className="container">
                    <form onSubmit={this.handleSubmit}>
                        {/* Form fields code ... */}
                        <label>Image of Product</label>
                        <br />
                        <br />
                        <input
                            type="file"
                            id="fileInput"
                            style={{ display: 'none' }}
                            onChange={this.handleFileChange}
                        />
                        <button onClick={this.handleChooseFile}>Choose File</button>
                        <button type="submit" onClick={this.addToTable}>Submit</button>

                        {/* Menampilkan pesan kesalahan */}
                        {errors.productName && <p style={{ color: 'red' }}>{errors.productName}</p>}
                        {errors.productCategory && <p style={{ color: 'red' }}>{errors.productCategory}</p>}
                        {errors.productPrice && <p style={{ color: 'red' }}>{errors.productPrice}</p>}
                        {errors.productFreshness && <p style={{ color: 'red' }}>{errors.productFreshness}</p>}
                        {errors.selectedFile && <p style={{ color: 'red' }}>{errors.selectedFile}</p>}
                    </form>
                    {isDataSaved && (
                        <p style={{ color: 'green' }}>Data has been saved.</p>
                    )}

                    {/* Menampilkan tabel */}
                    {this.renderTable()}
                </div>
            </div>
        );
    }
}

export default CreateProduct;
