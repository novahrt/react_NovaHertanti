import React, { Component } from 'react';
import { BrowserRouter, Route, Switch, Link as RouterLink } from 'react-router-dom';
import CreateProduct from './CreateProduct';
import './styles.css';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isAuthenticated: false,
        };
    }

    login = () => {
        this.setState({ isAuthenticated: true });
    };

    logout = () => {
        this.setState({ isAuthenticated: false });
    };

    render() {
        const { isAuthenticated } = this.state;

        return (
            <BrowserRouter>
                <div>
                    <nav>
                        <ul>
                            {/* Hapus elemen <li> ini untuk menghilangkan rute ke formulir registrasi */}
                            {/* <li>
                                <RouterLink to="/register">Registrasi</RouterLink>
                            </li> */}
                            <li>
                                <RouterLink to="/login">Login</RouterLink>
                            </li>
                            <li>
                                <RouterLink to="/create-product">Create Product</RouterLink>
                            </li>
                        </ul>
                    </nav>

                    <Switch>
                        {/* Hapus rute ini untuk menghilangkan rute ke formulir registrasi */}
                        {/* <Route path="/register">
                            <RegistrationForm />
                        </Route> */}
                        <Route path="/login">
                            {isAuthenticated ? (
                                <div>
                                    <p>Selamat datang! Anda sudah login.</p>
                                    <button onClick={this.logout}>Logout</button>
                                </div>
                            ) : (
                                <div>
                                    <p>Silakan login untuk mengakses Create Product.</p>
                                    <button onClick={this.login}>Login</button>
                                </div>
                            )}
                        </Route>
                        <Route path="/create-product">
                            {isAuthenticated ? (
                                <CreateProduct />
                            ) : (
                                <div>
                                    <p>Silakan login untuk mengakses halaman Create Product.</p>
                                    <button onClick={this.login}>Login</button>
                                </div>
                            )}
                        </Route>
                        <Route path="/">
                            <h2>Halaman Utama (LandingPage)</h2>
                        </Route>
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}

export default App;
