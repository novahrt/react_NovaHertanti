import React from 'react';

function AboutMe() {
  return (
    <section id="about" className="about-section text-center">
      <div className="container px-4 px-lg-5">
        <div className="row gx-4 gx-lg-5 justify-content-center">
          <div className="col-lg-8">
            <h2 className="text-white mb-4">About Us</h2>
            <img
              src="/logo.jpg"
              alt="Logo"
              className="img-fluid mb-4"
            />
            <p className="text-white-50">
              Selamat datang di Uyeee Pedia. Kami adalah sebuah tim kreatif yang
              berfokus pada konten seputar anime dan budaya Jepang. Dengan berbagai
              pengalaman dan minat kami dalam dunia anime, kami berkomitmen untuk
              memberikan informasi yang menarik dan berkualitas kepada komunitas kami.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AboutMe;
