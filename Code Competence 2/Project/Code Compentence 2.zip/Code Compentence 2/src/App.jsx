import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Impor Bootstrap CSS
import Header from './components/Header';
import Masthead from './components/Masthead';
import About from './components/About'; // Impor komponen About
import Projects from './components/Projects';
import ContactUs from './components/ContactUs';
import AboutMe from './components/AboutMe';

function App() {
  return (
    <div className="App">
      <Header />
      <Masthead />
      <About /> {/* Gunakan komponen About di sini */}
      <Projects />
      <ContactUs />
      <AboutMe />
    </div>
  );
}

export default App;
