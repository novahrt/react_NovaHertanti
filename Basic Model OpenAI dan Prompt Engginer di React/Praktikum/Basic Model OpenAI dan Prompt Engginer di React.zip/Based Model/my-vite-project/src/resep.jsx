import React, { useState } from 'react';
import axios from 'axios';

const Resep = () => {
  const [input, setInput] = useState('');
  const [answer, setAnswer] = useState('');

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleAskQuestion = async () => {
    if (input.trim() === '') return;

    const question = input;
    setInput('');

    try {
      const response = await askQuestion(question);
      if (response === '') {
        setAnswer("Resep Anda Tidak Tersedia.");
      } else {
        setAnswer(response);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const askQuestion = async (question) => {
    const apiKey = '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';
    const endpoint = 'https://api.openai.com/v1/engines/davinci/completions';

    try {
      const response = await axios.post(endpoint, {
        model: 'text-davinci-003',
        prompt: `Q: ${question}\nA: Resep Brownies:\nBerikut adalah resep sederhana untuk membuat Brownies:\nPanaskan oven hingga 180 derajat Celsius.\nCampurkan 200 gram cokelat pekat dengan 100 gram mentega, lalu lelehkan dalam wadah tahan panas di atas air mendidih.\nCampurkan 200 gram gula dan 3 butir telur dalam mangkuk besar hingga rata.\nTambahkan campuran cokelat dan mentega ke dalam adonan gula dan telur, lalu aduk rata.\nAyak 100 gram tepung terigu dan 25 gram bubuk kakao ke dalam adonan, lalu aduk hingga tercampur dengan baik.\nTuang adonan ke dalam loyang yang sudah dialasi kertas roti.\nPanggang dalam oven selama 25-30 menit atau hingga permukaannya kering dan bagian tengahnya mengembang.\nDinginkan sebelum memotong menjadi potongan-potongan kecil.`,
        max_tokens: 50,
      }, {
        headers: {
          'Authorization': `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`,
          'Content-Type': 'application/json',
        },
      });

      return response.data.choices[0].text;
    } catch (error) {
      throw error;
    }
  };

  return (
    <div className="container">
      <h1>Ask a Question</h1>
      <div>
        <input
          type="text"
          placeholder="Ask a question..."
          value={input}
          onChange={handleInputChange}
        />
        <button onClick={handleAskQuestion}>Ask</button>
      </div>
      {answer && (
        <div>
          <h2>Answer:</h2>
          <p>{answer}</p>
        </div>
      )}
    </div>
  );
};

export default Resep;
