import React from 'react';
import './App.css';
import Chatbot from 'Chatbot';
import Resep from './resep';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>OpenAI Chatbot</h1>
      </header>
      <Chatbot />
      <Resep />
    </div>
  );
}

export default App;
