import React, { useEffect } from 'react';
import App from '../App';

function App() {
    useEffect(() => {
        // Ketika komponen "CreateProduct" di-mount (dibuka), tampilkan alert "Welcome"
        alert('Welcome');
    }, []); // [] sebagai dependencies agar efek ini hanya terjadi sekali saat komponen di-mount

    return (
        <div>
            {/* Isi halaman "CreateProduct" */}
        </div>
    );
}

export default App;