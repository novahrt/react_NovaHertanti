import React, { useState, useEffect } from 'react';
import App from './App.jsx';
import { v4 as uuidv4 } from 'uuid';

function App() {
  const [productNumber, setProductNumber] = useState(1005);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [alertMessage, setAlertMessage] = useState('');

  // useEffect untuk pesan "Welcome" saat komponen dimounting
  useEffect(() => {
    setAlertMessage('Welcome');
  }, []);

  const handleInsert = () => {
    // Menambahkan produk baru ke dalam daftar produk
    const newProduct = {
      number: productNumber,
      name: 'New Product',
      category: 'Category',
      freshness: 'Freshness',
      price: 'Price',
    };

    setProducts([...products, newProduct]);
    setProductNumber(productNumber + 1);
  };

  const handleDelete = (productId) => {
    // Menampilkan notifikasi penghapusan
    setShowDeleteConfirmation(true);
    setSelectedProductId(productId);
  };

  const confirmDelete = () => {
    // Menghapus produk terpilih dari daftar produk
    const updatedProducts = products.filter(
      (product) => product.number !== selectedProductId
    );
    setProducts(updatedProducts);
    setShowDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    // Membatalkan penghapusan
    setShowDeleteConfirmation(false);
  };

  const handleSearch = () => {
    // Mencari produk berdasarkan nama
    const foundProduct = products.find(
      (product) =>
        product.name.toLowerCase() === searchTerm.toLowerCase()
    );

    if (foundProduct) {
      alert(`Product found: ${foundProduct.name}`);
    } else {
      alert('Product not found.');
    }
  };

  return (
    <div>
      {alertMessage && <div className="alert">{alertMessage}</div>}
      <button id="insertBtn" onClick={handleInsert}>
        Insert
      </button>
      <input
        id="search"
        type="text"
        placeholder="Search"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button id="searchBtn" onClick={handleSearch}>
        Search
      </button>

      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Product Name</th>
            <th>Product Category</th>
            <th>Product Freshness</th>
            <th>Product Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.number}>
              <td>{product.number}</td>
              <td>{product.name}</td>
              <td>{product.category}</td>
              <td>{product.freshness}</td>
              <td>{product.price}</td>
              <td>
                <button onClick={() => handleDelete(product.number)}>
                  Delete
                </button>
                {/* Tombol edit */}
                {/* <button onClick={() => handleEdit(product.number)}>Edit</button> */}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Notifikasi penghapusan */}
      {showDeleteConfirmation && (
        <div className="confirmation">
          <p>Apakah Anda yakin ingin menghapus produk ini?</p>
          <button onClick={confirmDelete}>Ya</button>
          <button onClick={cancelDelete}>Tidak</button>
        </div>
      )}
    </div>
  );
}

export default App;
