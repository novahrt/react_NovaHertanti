import React from 'react';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux'; // Ubah import dari 'redux' menjadi 'createStore' dan 'applyMiddleware'.
import thunk from 'redux-thunk'; // Import middleware Redux Thunk.
import rootReducer from './reducers'; // Sesuaikan dengan nama file reducer Anda.
import ProductList from './components/ProductList';

// Buat toko Redux dengan middleware Redux Thunk.
const store = createStore(rootReducer, applyMiddleware(thunk));

function App() {
  return (
    <Provider store={store}>
      <ProductList />
      {/* Komponen Anda */}
    </Provider>
  );
}

export default App;
