import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './reducers'; // Import your Redux reducers.
import ProductList from './components/ProductList';
import Login from './Login';
import SignUp from './components/signup'; // Import SignUp component

const store = createStore(rootReducer, applyMiddleware(thunk));

function App() {
  // State to manage your data
  const [data, setData] = useState('');

  // Function to save data in local storage
  const saveDataToLocal = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Function to retrieve data from local storage
  const getDataFromLocal = (key) => {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  }

  // Initialize data from local storage when the component mounts
  useEffect(() => {
    const savedData = getDataFromLocal('myData');
    if (savedData) {
      setData(savedData);
    }
  }, []);

  // Handle changes to your data
  const handleDataChange = (event) => {
    const newValue = event.target.value;
    setData(newValue);
    // Save the updated data in local storage
    saveDataToLocal('myData', newValue);
  }

  return (
    <Provider store={store}>
      <BrowserRouter>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/signup" component={SignUp} /> {/* Add route for Sign Up */}
          <Route path="/list-product">
            <div className="App">
              <input
                type="text"
                value={data}
                onChange={handleDataChange}
              />
              <p>Data in Local Storage: {data}</p>
              <ProductList />
              {/* Add your components here */}
            </div>
          </Route>
          <Redirect from="/" to="/list-product" />
        </Switch>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
