import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';

function ProductList() {
  const [rowCounter, setRowCounter] = useState(1);
  const [editingRow, setEditingRow] = useState(null);
  const [addFormData, setAddFormData] = useState({
    addName: '',
    addCategory: '',
    addImage: '',
    addFreshness: '',
    addDescription: '',
    addPrice: '',
  });

  const [productData, setProductData] = useState([]);
  const history = useHistory();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Periksa apakah pengguna sudah login (berdasarkan local storage)
    const userToken = localStorage.getItem('userToken');
    if (userToken) {
      setIsLoggedIn(true);
    }
    fetchDataFromMockAPI();
  }, []);

  const fetchDataFromMockAPI = async () => {
    try {
      const response = await axios.get('https://6529fbdb55b137ddc83f3b3b.mockapi.io/product');
      const data = response.data;
      setProductData(data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const showInsertForm = () => {
    setAddFormData({
      addName: '',
      addCategory: '',
      addImage: '',
      addFreshness: '',
      addDescription: '',
      addPrice: '',
    });
    setEditingRow(null);
  };

  const hideInsertForm = () => {
    setEditingRow(null);
  };

  const insertRow = () => {
    const newRowCounter = rowCounter + 1;
    setRowCounter(newRowCounter);
    hideInsertForm();

    const newRow = {
      id: newRowCounter,
      name: '',
      category: '',
      image: '',
      freshness: '',
      description: '',
      price: '',
    };

    setProductData([...productData, newRow]);
  };

  const editRow = (rowNumber) => {
    if (editingRow !== null) {
      cancelEdit();
    }

    setEditingRow(rowNumber);

    if (rowNumber !== null) {
      const product = productData.find((item) => item.id === rowNumber);
      setAddFormData({
        addName: product.name,
        addCategory: product.category,
        addImage: product.image,
        addFreshness: product.freshness,
        addDescription: product.description,
        addPrice: product.price,
      });
    }
  };

  const saveEdit = () => {
    if (editingRow !== null) {
      const editedProductData = productData.map((item) => {
        if (item.id === editingRow) {
          return {
            ...item,
            name: addFormData.addName,
            category: addFormData.addCategory,
            image: addFormData.addImage,
            freshness: addFormData.addFreshness,
            description: addFormData.addDescription,
            price: addFormData.addPrice,
          };
        }
        return item;
      });

      setProductData(editedProductData);
      hideInsertForm();
    }
  };

  const deleteRow = (rowNumber) => {
    const updatedProductData = productData.filter((item) => item.id !== rowNumber);
    setProductData(updatedProductData);
  };

  const cancelEdit = () => {
    hideInsertForm();
  };

  const closeModal = () => {
    if (editingRow === null) {
      hideInsertForm();
    }
  };

  const handleAddInputChange = (e) => {
    const { name, value } = e.target;
    setAddFormData({ ...addFormData, [name]: value });
  };

  const createProduct = async () => {
    try {
      const response = await axios.post('https://6529fbdb55b137ddc83f3b3b.mockapi.io/product', addFormData);
      const createdProduct = response.data;
      setProductData([...productData, createdProduct]);
      showSuccessMessage('Product created successfully');
      showInsertForm();
    } catch (error) {
      showErrorMessage('Failed to create product');
      console.error('Error creating product:', error);
    }
  };

  const updateProduct = async () => {
    if (!editingRow) return;

    try {
      const response = await axios.put(
        `https://6529fbdb55b137ddc83f3b3b.mockapi.io/product/${editingRow}`,
        addFormData
      );

      const updatedProduct = response.data;
      const updatedData = productData.map((item) =>
        item.id === editingRow ? updatedProduct : item
      );

      setProductData(updatedData);
      showSuccessMessage('Product updated successfully');
      hideInsertForm();
    } catch (error) {
      showErrorMessage('Failed to update product');
      console.error('Error updating product:', error);
    }
  };

  const deleteProduct = async (productId) => {
    try {
      await axios.delete(`https://6529fbdb55b137ddc83f3b3b.mockapi.io/product/${productId}`);
      const updatedData = productData.filter((item) => item.id !== productId);
      setProductData(updatedData);
      showSuccessMessage('Product deleted successfully');
    } catch (error) {
      showErrorMessage('Failed to delete product');
      console.error('Error deleting product:', error);
    }
  };

  const showSuccessMessage = (message) => {
    alert(message); // Anda dapat menampilkan pesan ini dengan cara yang lebih baik
  };

  const showErrorMessage = (message) => {
    alert(message); // Anda dapat menampilkan pesan ini dengan cara yang lebih baik
  };

  return (
    <div>
      <h2>List of Products</h2>
      {isLoggedIn ? (
        <div>
          {/* Tampilkan daftar produk dan tombol Logout */}
          <button onClick={handleLogout}>Logout</button>
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Product Name</th>
                <th>Product Category</th>
                <th>Image of Product</th>
                <th>Product Freshness</th>
                <th>Additional Description</th>
                <th>Product Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="productTableBody">
              {productData.map((product) => (
                <tr key={product.id}>
                  <td>{product.id}</td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addName"
                        value={addFormData.addName}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.name
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addCategory"
                        value={addFormData.addCategory}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.category
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addImage"
                        value={addFormData.addImage}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.image
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addFreshness"
                        value={addFormData.addFreshness}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.freshness
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addDescription"
                        value={addFormData.addDescription}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.description
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <input
                        type="text"
                        name="addPrice"
                        value={addFormData.addPrice}
                        onChange={handleAddInputChange}
                      />
                    ) : (
                      product.price
                    )}
                  </td>
                  <td>
                    {editingRow === product.id ? (
                      <button onClick={saveEdit}>Save</button>
                    ) : (
                      <div>
                        <button className="edit" onClick={() => editRow(product.id)}>
                          Edit
                        </button>
                        <button className="delete" onClick={() => deleteRow(product.id)}>
                          Delete
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="8">
                  <button className="insert" onClick={insertRow}>
                    Insert
                  </button>
                </td>
              </tr>
            </tfoot>
          </table>
          <div id="insertForm" className={`insert-form ${editingRow !== null ? 'show' : ''}`}>
            <h3>Add Product</h3>
            <form id="addForm">
              <label htmlFor="addName">Product Name:</label>
              <input
                type="text"
                id="addName"
                name="addName"
                value={addFormData.addName}
                onChange={handleAddInputChange}
              />
              <br />
              <label htmlFor="addCategory">Product Category:</label>
              <input
                type="text"
                id="addCategory"
                name="addCategory"
                value={addFormData.addCategory}
                onChange={handleAddInputChange}
              />
              <br />
              <label htmlFor="addImage">Image of Product:</label>
              <input
                type="text"
                id="addImage"
                name="addImage"
                value={addFormData.addImage}
                onChange={handleAddInputChange}
              />
              <br />
              <label htmlFor="addFreshness">Product Freshness:</label>
              <input
                type="text"
                id="addFreshness"
                name="addFreshness"
                value={addFormData.addFreshness}
                onChange={handleAddInputChange}
              />
              <br />
              <label htmlFor="addDescription">Additional Description:</label>
              <input
                type="text"
                id="addDescription"
                name="addDescription"
                value={addFormData.addDescription}
                onChange={handleAddInputChange}
              />
              <br />
              <label htmlFor="addPrice">Product Price:</label>
              <input
                type="text"
                id="addPrice"
                name="addPrice"
                value={addFormData.addPrice}
                onChange={handleAddInputChange}
              />
              <br />
              <button type="button" onClick={createProduct}>
                Create
              </button>
              <button type="button" onClick={cancelEdit}>
                Cancel
              </button>
            </form>
          </div>
        </div>
      ) : (
        <p>Silakan login untuk mengakses daftar produk.</p>
      )}
    </div>
  );
}

export default ProductList;