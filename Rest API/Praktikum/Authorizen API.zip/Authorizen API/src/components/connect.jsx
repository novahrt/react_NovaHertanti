import React from 'react';
import { connect } from 'react-redux';

const YourComponent = (props) => {
  // Anda dapat mengakses produk dari props
  const { products } = props;

  return (
    <div>
      <h2>List of Products</h2>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Product Name</th>
            <th>Product Category</th>
            <th>Image of Product</th>
            <th>Product Freshness</th>
            <th>Additional Description</th>
            <th>Product Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product, index) => (
            <tr key={product.id}>
              <td>{index + 1}</td>
              <td>{product.productName}</td>
              <td>{product.productCategory}</td>
              <td>{product.image}</td>
              <td>{product.productFreshness}</td>
              <td>{product.additionalDescription}</td>
              <td>{product.productPrice}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    products: state.products, // Mengambil produk dari state Redux
  };
};

export default connect(mapStateToProps)(YourComponent);
