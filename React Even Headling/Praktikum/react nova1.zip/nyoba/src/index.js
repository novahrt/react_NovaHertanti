import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import App from "./App.js";
import "./css/main.css";
import Button from "../src/button.js";

function showErrorField(element) {
  element.style.border = "1px solid red";
  const errorIcon = document.createElement("i");
  errorIcon.className = "bi bi-x-circle-fill text-danger";
  element.insertAdjacentElement("afterend", errorIcon);
}

function clearErrorField(element) {
  element.style.border = "";
  const errorIcon = element.nextElementSibling;
  if (errorIcon && errorIcon.className.includes("bi-x-circle-fill")) {
      errorIcon.remove();
  }
}

function validateForm(e) {
  e.preventDefault();

  let productName = document.getElementById("productName");
  let productCategory = document.getElementById("productCategory");
  let productPrice = document.getElementById("productPrice");
  let selectedFreshness = document.querySelector('input[name="freshness"]:checked');
  let additionalDescription = document.getElementById("additionalDescription");

  if (productName.value.length > 10) {
      showErrorField(productName);
      return false;
  }

  clearErrorField(productName);

  // Formulir valid, kirimkan formulir ke server
  // document.querySelector("form").submit();
}

const freshnessOptions = document.querySelectorAll('input[name="freshness"]');
freshnessOptions.forEach(option => {
  option.addEventListener("click", function() {
      freshnessOptions.forEach(otherOption => {
          otherOption.checked = false;
          clearErrorField(otherOption);
      });
      this.checked = true;
      clearErrorField(this);
  });
});

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
    <Button />
  </React.StrictMode>
);
