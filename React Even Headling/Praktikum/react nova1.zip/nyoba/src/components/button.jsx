import React from "react";

const Button = () => {
  const [text, setText] = useState("Generate Random Number");

  const handleClick = () => {
    setText("Random Number Generated!");
  };

  return (
    <button onClick={handleClick}>
      {text}
    </button>
  );
};

export default Button;
