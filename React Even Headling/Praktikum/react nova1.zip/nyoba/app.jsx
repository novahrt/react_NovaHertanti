import React from "react";
import { Link } from "react-router-dom";
import "../src/css/main.css";
import CreateProduct from "../src/components/CreateProduct.js";

// Import Button dari direktori yang sama
import Button from "../nyoba/src/button.js";

// Import article dari direktori yang sama
import article from "..nyoba/src/article.js";

const App = () => {
  return (
    <div>
      <header>
        <Link to="/">Home</Link>
        <Link to="/create-product">Create Product</Link>
      </header>
      <main>
        <Route path="/create-product" component={CreateProduct} />
        <Route path="/" component={Home} />
      </main>
      <footer>
        <p>Copyright 2023</p>
      </footer>
    </div>
  );
};

const Home = () => {
  return (
    <div>
      <h1>Home Page</h1>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
    <Button />
    <article />
  </React.StrictMode>
);

export default App;
