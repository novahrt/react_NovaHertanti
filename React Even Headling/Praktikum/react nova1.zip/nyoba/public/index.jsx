import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import App from "./App.js";
import "./css/main.css";
import Button from "../src/button.js";

function showErrorField(element) {
  element.style.border = "1px solid red";
  const errorIcon = document.createElement("i");
  errorIcon.className = "bi bi-x-circle-fill text-danger";
  element.insertAdjacentElement("afterend", errorIcon);
}

function clearErrorField(element) {
  element.style.border = "";
  const errorIcon = element.nextElementSibling;
  if (errorIcon && errorIcon.className.includes("bi-x-circle-fill")) {
      errorIcon.remove();
  }
}

function validateForm(e) {
  e.preventDefault();

  let productName = document.getElementById("productName").value;
  let productCategory = document.getElementById("productCategory").value;
  let productPrice = document.getElementById("productPrice").value;
  let additionalDescription = document.getElementById("additionalDescription").value;

  if (productName.length < 10 || productName.length > 25) {
      alert("Product Name must be between 10 and 25 characters.");
      showErrorField(productName);
      return false;
  }

  if (!productPrice.match(/^\d+$/)) {
      alert("Product Price must be a number.");
      showErrorField(productPrice);
      return false;
  }

  return true;
}

const submitButton = document.querySelector("#submitButton");
submitButton.addEventListener("click", validateForm);

const language = useState("english");

function changeLanguage() {
  language = language === "english" ? "indonesia" : "english";
}

function render() {
  return (
    <div>
      <h1>{language === "english" ? "Create Product" : "Buat Produk"}</h1>
      <form onSubmit={validateForm}>
        <label htmlFor="productName">Product Name</label>
        <input
          type="text"
          id="productName"
          required
          placeholder="Enter product name"
        />
        <label htmlFor="productCategory">Product Category</label>
        <select id="productCategory">
          <option value="choose">Choose</option>
          <option value="food">Food</option>
          <option value="electronics">Electronics</option>
          <option value="clothing">Clothing</option>
        </select>
        <label htmlFor="productPrice">Product Price</label>
        <input
          type="number"
          id="productPrice"
          required
          placeholder="Enter product price"
        />
        <label htmlFor="additionalDescription">Additional Description</label>
        <textarea
          id="additionalDescription"
          required
          placeholder="Enter additional description"
        />
        <Button text="Submit" />
      </form>
      <button onClick={changeLanguage}>{language === "english" ? "Bahasa Indonesia" : "English"}</button>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
