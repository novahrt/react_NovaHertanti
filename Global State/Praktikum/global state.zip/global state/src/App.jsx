import redux from 'redux';
import { Provider } from 'react-redux';
import ProductList from './components/ProductList';

// Reducer Anda akan ditambahkan di sini.
// Misalnya, Anda dapat membuat file reducer.js dan mengimpor reducer tersebut di sini.

import rootReducer from './reducers'; // Sesuaikan dengan nama file reducer Anda.

// Buat toko Redux dengan reducer Anda.
const store = redux(rootReducer);

function App() {
  return (
    <Provider store={store}>
      <ProductList>
      </ProductList>
      {/* Komponen Anda */}
    </Provider>
  );
}

export default App;
