import React, { useState } from 'react';
import axios from 'axios';

const Chatbot = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleSendMessage = async () => {
    if (input.trim() === '') return;

    const userMessage = input;
    addMessage('You', userMessage);

    try {
      const response = await sendUserMessage(userMessage);
      addMessage('Chatbot', response);
    } catch (error) {
      console.error(error);
    }

    setInput('');
  };

  const sendUserMessage = async (message) => {
    // Gantilah 'YOUR_API_KEY' dengan kunci API OpenAI Anda
    const apiKey = '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';
    const endpoint = 'https://api.openai.com/v1/engines/davinci/completions';

    try {
      const response = await axios.post(endpoint, {
        model: 'text-davinci-003',
        prompt: message,
        max_tokens: 50,
      }, {
        headers: {
          'Authorization': `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`,
          'Content-Type': 'application/json',
        },
      });

      return response.data.choices[0].text;
    } catch (error) {
      throw error;
    }
  };

  const addMessage = (sender, message) => {
    setMessages([...messages, { sender, message }]);
  };

  return (
    <div className="container">
      <div className="chatbox">
        <div className="messages">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`message ${message.sender === 'You' ? 'user' : 'bot'}`}
            >
              <strong>{message.sender}:</strong> {message.message}
            </div>
          ))}
        </div>
        <div className="input">
          <input
            type="text"
            placeholder="Type your message..."
            value={input}
            onChange={handleInputChange}
          />
          <button onClick={handleSendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
