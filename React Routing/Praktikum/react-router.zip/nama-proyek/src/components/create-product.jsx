import React from "react";
import { useHistory } from "react-router-dom"; // Import useHistory dari react-router-dom
import "./styles.css";

const CreateProduct = () => {
  const history = useHistory(); // Inisialisasi useHistory

  const handleSubmit = (event) => {
    event.preventDefault();
    
    // Lakukan pemrosesan formulir di sini

    // Setelah pemrosesan berhasil, arahkan pengguna ke halaman Landing Page
    history.push('/');
  };

  return (
    <div>
      {/* Isi formulir Create Product di sini */}
      <form onSubmit={handleSubmit}>
        {/* Isi formulir di sini */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default CreateProduct;
