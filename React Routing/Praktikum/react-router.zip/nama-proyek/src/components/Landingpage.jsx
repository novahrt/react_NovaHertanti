import React from "react";
import { Link } from "react-router-dom"; // Import Link dari react-router-dom
import "./styles.css";

const LandingPage = () => {
    return (
      <div>
        <div className="navbar">
          <a href="#contact">Contact</a>
          <a href="#services">Service</a>
          <a href="#about">About</a>
          <a href="#home">Home</a>
          < a href="#create-product.html">Create Product</a>
        </div>
  
        <div className="content" id="content-section">
          <div className="content-text">
            <h1>Better Solutions For Your Business</h1>
            <p>We are a team of talented designers making websites with Bootstrap.</p>
            <div className="buttons">
              <Link to="/create-product" className="button">Create Product</Link>
              <button>Watch Video</button>
            </div>
          </div>
          <img className="right-image" src="5.jpg" alt="Image" />
        </div>
  
        <div className="footer">
          <div className="footer-row">
            <div>
              <h2>ARSHA</h2>
              <p>A108 Adam Street</p>
              <p>New York, NY 535022</p>
              <p>United States</p>
              <div>
                <h3>Phone:</h3>
                <p>+1 5589 55488 55</p>
              </div>
              <div>
                <h3>Email:</h3>
                <p>info@example.com</p>
              </div>
            </div>
            <div>
              <h2>Useful Links</h2>
              <p>Home</p>
              <p>About Us</p>
              <p>Service</p>
              <p>Terms of Service</p>
              <p>Privacy Policy</p>
            </div>
            <div>
              <h2>Our Service</h2>
              <p>Web Design</p>
              <p>Web Development</p>
              <p>Product Management</p>
              <p>Marketing</p>
              <p>Graphic Design</p>
            </div>
            <div>
              <h2>Our Social Network</h2>
            </div>
          </div>
        </div>
  
        <div className="footer">
          <p>Copyright © 2023 Arsha. All rights reserved.</p>
        </div>
      </div>
    );
  };
  
  export default LandingPage;