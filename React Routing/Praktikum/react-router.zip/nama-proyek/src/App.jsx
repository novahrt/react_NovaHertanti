import React, { useState } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import LandingPage from "./LandingPage";
import CreateProduct from "./CreateProduct";
import PrivateRoute from "./PrivateRoute"; // Impor komponen PrivateRoute
import "./styles.css";

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Status login pengguna

  // Fungsi untuk melakukan login
  const login = () => {
    setIsAuthenticated(true);
  };

  // Fungsi untuk melakukan logout
  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <BrowserRouter>
      <div>
        <Switch>
          <Route path="/login">
            {/* Halaman login */}
            <button onClick={login}>Login</button>
          </Route>
          {/* Gunakan PrivateRoute untuk halaman yang hanya dapat diakses oleh pengguna yang sudah login */}
          <PrivateRoute
            path="/create-product"
            component={CreateProduct}
            isAuthenticated={isAuthenticated}
          />
          <Route path="/">
            <LandingPage />
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
};

export default App;
