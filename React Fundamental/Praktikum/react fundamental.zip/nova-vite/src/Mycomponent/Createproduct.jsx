import React, { useState } from "react";
import "../assets/styles1.css";
import "../assets/Createproduct";
import "../gambar/logo.png";

function CreateProduct() {
  const [productName, setProductName] = useState("");
  const [productCategory, setProductCategory] = useState("");
  const [file, setFile] = useState(null);
  const [productFreshness, setProductFreshness] = useState([]);
  const [additionalDescription, setAdditionalDescription] = useState("");
  const [productPrice, setProductPrice] = useState("");

  const handleProductNameChange = (event) => {
    setProductName(event.target.value);
  };

  const handleProductCategoryChange = (event) => {
    setProductCategory(event.target.value);
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleProductFreshnessChange = (event) => {
    setProductFreshness([...event.target.checked]);
  };

  const handleAdditionalDescriptionChange = (event) => {
    setAdditionalDescription(event.target.value);
  };

  const handleProductPriceChange = (event) => {
    setProductPrice(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Validate the form data

    // Submit the form data
  };

  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <label htmlFor="productName">Product Name</label>
        <input
          type="text"
          id="productName"
          name="productName"
          value={productName}
          onChange={handleProductNameChange}
          required
        />

        <label htmlFor="productCategory">Product Category</label>
        <select
          id="productCategory"
          name="productCategory"
          value={productCategory}
          onChange={handleProductCategoryChange}
          required
        >
          <option value="choose">Choose</option>
          <option value="Elektronik">Elektronik</option>
          <option value="Kendaraan">Kendaraan</option>
          <option value="Make Up">Make Up</option>
          <option value="Fashion">Fashion</option>
        </select>

        <label>Image of Product</label>
        <input
          type="file"
          id="fileInput"
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
        <button id="chooseFileButton">Choose File</button>

        <label for="imageofproduct">No file chosen</label>

        <label htmlFor="productFreshness">Product Freshness:</label>

        <ol id="productFreshness">
          <ul>
            <li>
              <input
                type="checkbox"
                name="freshness"
                value="Brand New"
                checked={productFreshness.includes("Brand New")}
                onChange={handleProductFreshnessChange}
              />
              Brand New
            </li>
          </ul>
          <ul>
            <li>
              <input
                type="checkbox"
                name="freshness"
                value="Second Hand"
                checked={productFreshness.includes("Second Hand")}
                onChange={handleProductFreshnessChange}
              />
              Second Hand
            </li>
          </ul>
          <ul>
            <li>
              <input
                type="checkbox"
                name="freshness"
                value="Refurbished"
                checked={productFreshness.includes("Refurbished")}
                onChange={handleProductFreshnessChange}
              />
              Refurbished
            </li>
          </ul>
        </ol>

        <label htmlFor="additionalDescription">Additional Description</label>
        <textarea
          id="additionalDescription"
          name="additionalDescription"
          value={additionalDescription}
          onChange={handleAdditionalDescriptionChange}
          required
        />

        <label htmlFor="productPrice">Product Price:</label>
        <input
          type="text"
          id="productPrice"
          name="productPrice"
          value={productPrice}
          onChange={handleProductPriceChange}
          required
        />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default CreateProduct;