<header>
  <h1>Create Product</h1>
</header>
