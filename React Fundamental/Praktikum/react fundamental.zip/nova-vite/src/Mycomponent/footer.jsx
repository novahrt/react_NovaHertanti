<footer>
        <p>Copyright &copy; 2023</p>
      </footer>